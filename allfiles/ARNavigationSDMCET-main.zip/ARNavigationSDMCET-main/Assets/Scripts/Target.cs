using System;
using UnityEngine;


[System.Serializable]
public class Target
{
    public string Name;
    public GameObject PositionObject;

}
