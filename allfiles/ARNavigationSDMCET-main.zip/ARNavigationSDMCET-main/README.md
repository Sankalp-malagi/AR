
# ARNavigation SDMCET, Dharwad

ARNavigation is an Augmented Reality Navigation app implemented on the campus of SDMCET, Dharwad.
You can choose a Destination in the campus and the app will guide you to your destination. 


## Technologies Used

We used Unity as a platform to build the application and AR Core toolkit to render the path.


## Technologies Used

We used Unity as a platform to build the application and AR Core toolkit to render the path.


## Project Developers
This is an application built as a final year project by SDMCET students.
Members of this Project are:-
Ashish Kalghatkar, Sandeep B. , Sankalp Malagi and Vagesh Naik.